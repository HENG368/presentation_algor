#include <iostream>
#include "condidate.hpp"
#include "tournament.hpp"
#include "rng.hpp"

using namespace std;

// Winner: highest value wins
bool nodeWinner(Node a, Node b) {
    return a.value > b.value;
}

// Round structure
struct MatchRound {
    vector<pair<Node, Node>> matches;
    vector<Node> autoAdvance;
};

// Build matches for all rounds
vector<MatchRound> buildMatchList(vector<Node> players, bool (*isWinner)(Node,Node)) {
    vector<MatchRound> rounds;

    while (players.size() > 1) {
        MatchRound round;
        vector<Node> next;

        for (size_t i = 0; i < players.size(); i += 2) {
            if (i + 1 < players.size()) {
                // Normal match
                Node A = players[i];
                Node B = players[i+1];
                round.matches.push_back({A, B});

                next.push_back(isWinner(A, B) ? A : B);
            } else {
                // Odd player auto-advance
                round.autoAdvance.push_back(players[i]);
                next.push_back(players[i]);
            }
        }

        rounds.push_back(round);

        players = next;
    }

    return rounds;
}

int main() {
    rng::setSeed(static_cast<uint32_t>(std::random_device{}()));

    // Add players
    addRandomNode("Alice");
    addRandomNode("Bob");
    addRandomNode("Charlie");
    addRandomNode("David");
    addRandomNode("Dara");  // odd player

    // --- Print participants ---
    cout << "This is our participation\n";
    for (auto &n : nodes)
        cout << n.Name << "\n";
    cout << "\n";

    // Build logical rounds
    auto rounds = buildMatchList(nodes, nodeWinner);

    // --- Print rounds ---
    for (size_t r = 0; r < rounds.size(); r++) {
        cout << "Round " << (r + 1) << ":\n";

        for (auto &m : rounds[r].matches) {
            cout << "  " << m.first.Name << "(" << m.first.value << ")"
                 << " vs "
                 << m.second.Name << "(" << m.second.value << ")\n";
        }

        for (auto &autoP : rounds[r].autoAdvance) {
            cout << "  " << autoP.Name << " auto-advances\n";
        }

        cout << "\n";
    }

    // FINAL WINNER USING TOURNAMENT TREE
    TreeNode<Node>* root = tournament_tree(nodes, nodeWinner);

    cout << "Final Winner: "
         << root->data.Name << " (" << root->data.value << ")\n";

    return 0;
}
